#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

int main(int argv, char *argc[]) {
    int x = 0;
    char filename[30];
    strncpy(filename, argc[2],30);
    if (argc[1][1] == 'D') { 
    
    
    FILE *fp1;
    FILE *fp2;
    fp1 = fopen(argc[2],"r");
    char filecont[121];
    int t = 0 ;
    char c;
    c = fgetc(fp1);
    while(c != EOF){
        filecont[t]= c; 
        t = t+1;
        c = fgetc(fp1);
    }
    strcat(filename, ".txt");
    fp2 = fopen(filename, "w");
    while(x < strlen(filecont))
    {
        int hex1 = filecont[x]; 
        int hex2 = filecont[x+1]; 
        int outChar;
        int temp1, temp2;
        if(hex1 == 'T' && hex2 == 'T') outChar = 9; 
        if (hex1 == 'A') {
            temp1 = 10;
        } 
        else if (hex1 == 'B') {
            temp1 = 11;
        }
        else if (hex1 == 'C'){
            temp1 = 12; 
        }
        else if (hex1 == 'D'){
            temp1 = 13;
        }
        else if (hex1 == 'E'){
            temp1 = 14;
        }
        else if (hex1 == 'F'){
            temp1 = 15;
        }
        else{
            temp1 = filecont[x];
        }

        if (hex2 == 'A'){
            temp2 = 10;
        } 
        else if (hex2 == 'B'){
            temp2 = 11;
        }
        else if (hex2 == 'C'){
            temp2 = 12; 
        }
        else if (hex2 == 'D'){
            temp2 = 13;
        }
        else if (hex2 == 'E'){
            temp2 = 14;
        }
        else if (hex2 == 'F'){
            temp2 = 15;
        }
         else{
            temp2 = filecont[x+1];
        }

        outChar = (temp1 * 16) + temp2;
        outChar += 16;

        if(outChar > 127){ 
            outChar = (outChar - 144) + 32;
        }

        fprintf(fp2, "%d", outChar);

        x += 2;
    }
    
    }
    else {
    int length = strlen(filename);
    for (int i = 0; i < length; i++) {
        if (filename[i] == '.') {
            filename[i] = '\0';
            break;
        }
    }

    FILE *fp1;
    FILE *fp2;
    fp1 = fopen(argc[2],"r");
    char filecont[121];
    int t = 0 ;
    char c;
    c = fgetc(fp1);
    while(c != EOF){
        filecont[t]= c;
        t = t+1;
        c = fgetc(fp1);
    }
    strcat(filename, ".crp");
    fp2 = fopen(filename, "w");
    int encryptDec = 0;
    for(int t1 = 0;t1<t;++t1){
        encryptDec=filecont[t1]; 
        encryptDec=encryptDec-16;
        if(encryptDec<32){
            encryptDec = encryptDec-32;
            encryptDec = encryptDec+144; }
        else{}
        printf("%X", encryptDec);
        fprintf(fp2, "%X", encryptDec);
        
    }
} 
}